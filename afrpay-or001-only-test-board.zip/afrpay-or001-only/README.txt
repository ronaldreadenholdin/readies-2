AFRPAY TEST BOARD — OR001 ONLY
==============================

Correction: AfrPay does NOT include Open Banking.

Assigned number/code:
  OR001 = Onramp / card to crypto (USDT/USDC -> Readies)

NOT used for AfrPay:
  OB003 = Open Banking (was wrongly copied from CashForo dual template)

Open index.html or afrpay-or001-onramp-test-board.html in a browser.
